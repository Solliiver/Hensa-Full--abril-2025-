# 📚 Hensa
**Hensa** representa um coletivo composto por entusiastas dedicados à edição de conteúdo destinado à criação de servidores de roleplay para o jogo **Grand Theft Auto V**, utilizando a plataforma **FiveM**.

Acesse o nosso **Website**: [Clique aqui para entrar](https://hensa.store/).

-------

### 💬 Comunidade
Maiores informações você só encontra em nosso **Discord**: [Clique aqui para entrar](https://hensa.store/discord).

-------

## 📝 Licença

Este conteúdo é distribuído sob a **Licença __MIT__**. Consulte o arquivo `LICENSE` para obter mais detalhes.

-------

![Hensa](https://hensa.store/Mawu/image/LogoHensa.png "Hensa")
